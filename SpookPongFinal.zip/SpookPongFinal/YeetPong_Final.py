#########################################
# File Name: YeetPong_Final
# Description: PONG
# Author: Sunny, Michael, Justin
# Date: 10/29/18
#########################################

import pygame
from random import randint

pygame.mixer.pre_init(44100,-16,1, 1024)
pygame.init()
WIDTH  = 800
HEIGHT = 600
gameWindow = pygame.display.set_mode((WIDTH,HEIGHT))

TOP    = 0  
BOTTOM = HEIGHT
LEFT   = 0     
RIGHT  = WIDTH

GREEN = (  0,255,  0)
BLUE  = (  0,  0,128)
WHITE = (255,255,255)
BLACK = (  0,  0,  0)
GREY  = (100,100,100)
cheatColor = WHITE

outline = 0
flagY = False

font = pygame.font.SysFont("Courier Regular",75)
gameEndFont = pygame.font.SysFont("Courier Regular",150)
spookPong = pygame.image.load("spookpong.png").convert_alpha()
dootMan = pygame.image.load("mrskeletallarge.png").convert_alpha()
bone = pygame.image.load("mrskeletal.png").convert_alpha()
boneflip = pygame.image.load("mrskeletalflip.png").convert_alpha()
spookyMan = pygame.image.load("spookyman.png").convert()

pygame.mixer.music.load("spookmusic.ogg")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1)

toot = pygame.mixer.Sound("toot.wav")
toot.set_volume(0.5)

winSound = pygame.mixer.Sound("yay.wav")
winSound.set_volume(0.2)

pointSound = pygame.mixer.Sound("skeletonsound.wav")
pointSound.set_volume(0.3)

MAX_SCORE = 7

ballWaitTime = 0
pauseTime = 600
ballWaitOn = True

cheatAmount = 1
cheatActivated = False

#---------------------------------------#
# Functions                             #
#---------------------------------------#

def redrawGameWindow():
    gameWindow.fill(BLACK)
    pygame.draw.rect(gameWindow,GREY,(WIDTH/2-2,0,5,HEIGHT),outline)
    p1ScoreRender = font.render(str(player1Score), 1, WHITE)
    p2ScoreRender = font.render(str(player2Score), 1, WHITE)
    gameWindow.blit(p1ScoreRender,((WIDTH/2 + (WIDTH/2)/2),35))
    gameWindow.blit(p2ScoreRender,((WIDTH/2 - (WIDTH/2)/2),35))
    pygame.draw.rect(gameWindow, WHITE, (paddle1X, paddle1Y, paddleW, paddleH), outline)
    pygame.draw.rect(gameWindow, cheatColor, (paddle2X, paddle2Y, paddleW, paddleH), outline)

def redrawBall():
    if speedX > 0:
        gameWindow.blit(bone,(ballX-15,ballY-15))
    if speedX < 0:
        gameWindow.blit(boneflip,(ballX-15,ballY-15))

def redrawMainMenu():
    gameWindow.fill(BLACK)
    dootX = dootMan.get_width()
    gameWindow.blit(dootMan,(WIDTH/2-50, HEIGHT/2-50))
    gameWindow.blit(dootMan,(WIDTH/2 - 220, HEIGHT/2-100))
    gameWindow.blit(dootMan,(WIDTH/2 + 100,HEIGHT/2-100))
    menuMessage = font.render("Press ENTER to start",1,WHITE)
    menuMessageX = menuMessage.get_width()
    gameWindow.blit(menuMessage,(WIDTH/2 - menuMessageX/2,HEIGHT/2+HEIGHT/6))
    titleX = spookPong.get_width()
    gameWindow.blit(spookPong,(WIDTH/2 - titleX/2, HEIGHT/2-HEIGHT/4))

def drawGameOverBlock():
    gameWindow.fill(BLACK)
    pygame.draw.rect(gameWindow, WHITE, (WIDTH/2-250,HEIGHT/2-50, 500,80 ), 5)
    p1ScoreRender = gameEndFont.render(str(player1Score), 1, WHITE)
    p2ScoreRender = gameEndFont.render(str(player2Score), 1, WHITE)
    gameWindow.blit(p1ScoreRender,((WIDTH/2 + (WIDTH/2)/2),35))
    gameWindow.blit(p2ScoreRender,((WIDTH/2 - (WIDTH/2)/2),35))
    gameWindow.blit(winScreen,(WIDTH/2-170,HEIGHT/2-33))
    gameWindow.blit(spookyMan,(WIDTH/2-100,HEIGHT-250))
    winSound.play(0)
    pygame.display.update()

def randDirection():
    vertical = randint(0,1)
    if vertical == 0:
        return -1
    if vertical == 1:
        return 1
#---------------------------------------#
# Main Program                          #
#---------------------------------------#

# GAME INITIALIZATION

# players
player1Score = 0 # right side
player2Score = 0 # left side

# ball properties
ballR  = 15
ballX  =  WIDTH/2
ballY  =  HEIGHT/2
speedX =  randDirection()
speedY =  randDirection()

# paddle properties 
paddleW  = 20
paddleH  = 120
paddleShift = 2

# paddle 1
paddle1X = RIGHT - paddleW - 20
paddle1Y = (BOTTOM/2) - (paddleH/2)

# paddle 2
paddle2X = LEFT + 20
paddle2Y = (BOTTOM/2) - (paddleH/2)

# Clock and FPS
clock = pygame.time.Clock()
FPS = 500

############ MENU LOOP ###########

print "Hit ESC to end the program."

mainMenu = True
while mainMenu == True:
    redrawMainMenu()
    pygame.display.update()
    pygame.event.clear()
    keys = pygame.key.get_pressed()
    if keys[pygame.K_RETURN]:
        mainMenu = False
        print "YEET"
    elif keys[pygame.K_ESCAPE]:
        pygame.quit()

############ GAME LOOP ###########

redrawGameWindow()
redrawBall()
pygame.display.update()

inPlay = True

while inPlay:

    clock.tick(FPS)

    # ~~~~~~~ CHECK FOR WIN ~~~~~~~ #

    if player1Score == MAX_SCORE:
        inPlay = False
        speedX = 0
        speedY = 0
        closeGame = False

    elif player2Score == MAX_SCORE:
        inPlay = False
        speedX = 0
        speedY = 0
        closeGame = False

    # ~~~~~~~~ USER INPUTS ~~~~~~~ #
    
    pygame.event.clear()
    keys = pygame.key.get_pressed()
    if keys[pygame.K_ESCAPE]:
        inPlay = False
        closeGame = True
    if keys[pygame.K_a]:
        paddle2Y = paddle2Y - paddleShift
    if keys[pygame.K_d]:
        paddle2Y = paddle2Y + paddleShift
    if keys[pygame.K_LEFT]:
        paddle1Y = paddle1Y - paddleShift
    if keys[pygame.K_RIGHT]:
        paddle1Y = paddle1Y + paddleShift

    # ~~~~~~~~ DRAW WINDOW AND OBJECTS ~~~~~~~~ #

    redrawGameWindow()
    redrawBall()
    pygame.display.update()

    # ~~~~~~~ PREVENT PADDLES FROM GOING OFF-SCREEN ~~~~~~~ #

    if paddle1Y <= 0:
        paddle1Y = 0
    if paddle1Y >= BOTTOM - paddleH:
        paddle1Y = BOTTOM - paddleH

    if paddle2Y <= 0:
        paddle2Y = 0
    if paddle2Y >= BOTTOM - paddleH:
        paddle2Y = BOTTOM - paddleH

    # ~~~~~~~ BOUNCE FROM WALLS ~~~~~~~ #
    
    if ballY + ballR == BOTTOM:
        speedY = -speedY
    if ballY - ballR == TOP:
        speedY = -speedY

    # ~~~~~~~ BOUNCE FROM PADDLES ~~~~~~~ #

    # PADDLE 1
    if ballY >= paddle1Y and ballY <= paddle1Y + paddleH and ballX + ballR == paddle1X:
        speedX = -speedX
        toot.play(0)
    if ballX >= paddle1X and ballY + ballR >= paddle1Y and ballY + ballR <= paddle1Y + 60 or ballX >= paddle1X and ballY - ballR <= paddle1Y + paddleH and ballY - ballR >= paddle1Y + paddleH - 60:
        if flagY == False:
            speedY = -speedY
            flagY = True
        if flagY == True:
            speedY = speedY
        
    #PADDLE 2
    if ballY >= paddle2Y and ballY <= paddle2Y + paddleH and ballX - ballR == paddle2X + paddleW:
        speedX = -speedX
        toot.play(0)
    if ballX <= paddle2X + paddleW and ballY + ballR >= paddle2Y and ballY + ballR <= paddle2Y + 60 or ballX <= paddle2X + paddleW and ballY - ballR <= paddle2Y + paddleH and ballY - ballR >= paddle2Y + paddleH - 60:
        if flagY == False:
            speedY = -speedY
            flagY = True
        if flagY == True:
            speedY = speedY

    #  ~~~~~~~ INCREMENT SCORE ~~~~~~~ #
    
    # PADDLE 1
    if ballX == WIDTH:
        player2Score += 1
        ballX = WIDTH/2 + (WIDTH/2)/2
        ballY = HEIGHT/2
        flagY = False
        speedY = randDirection()
        speedX = -speedX
        pointSound.play(0)

        ballWaitOn = True

        if cheatActivated == True:
            cheatAmount = 0
            cheatColor = WHITE

    # PADDLE 2
    if ballX == 0:
        player1Score += 1
        ballX = WIDTH/2 - (WIDTH/2)/2
        ballY = HEIGHT/2
        flagY = False
        speedY = randDirection()
        speedX = -speedX
        pointSound.play(0)
        
        ballWaitOn = True

        if cheatActivated == True:
            cheatAmount = 0
            cheatColor = WHITE

    # ~~~~~~~ CHEAT ~~~~~~~#

    if ballX < WIDTH/5:
        ballEnemySide = True
    elif ballX > WIDTH/5:
        ballEnemySide = False
    
    if keys[pygame.K_BACKSLASH]:
        cheatActivated = True
    if cheatActivated == True:
        if cheatAmount == 1:
            if ballEnemySide:
                cheatColor = WHITE
            elif not ballEnemySide:
                cheatColor = BLACK
        
    # ~~~~~~~ MOVE BALL ~~~~~~~ #
        
    # Check whether the ball should wait
    # Ball waits before serving after a point is scored
    if ballWaitOn:
        ballWaitTime += 1
        if ballWaitTime == 500:
            ballWaitTime = 0
            ballWaitOn = False

    # If ball does not need to wait, or if wait time is up, move the ball
    else:
        ballX = ballX + speedX
        ballY = ballY + speedY

# ~~~~~~~ DISPLAY GAME END CARD ~~~~~~~ #

if closeGame == True:
    pygame.quit()

if closeGame == False:
    if player1Score == MAX_SCORE:
        winScreen = font.render(("Player 1 Wins"), 1, WHITE)
    else:
        winScreen = font.render(("Player 2 Wins"), 1, WHITE)

    drawGameOverBlock()
    pygame.time.delay(5000)

pygame.quit()
